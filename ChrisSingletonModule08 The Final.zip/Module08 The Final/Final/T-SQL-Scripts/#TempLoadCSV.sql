
IF OBJECT_ID('tempdb..#TempBellevueLoadCSV') IS NOT NULL
   DROP TABLE #TempLoadCSV
GO
CREATE --DROP
       TABLE #TempLoadCSV1
	   ( [Date] time NOT NULL 
	     ,Patient int NOT NULL
		 ,Doctor int NOT NULL
		 ,[Procedure] int NOT NULL
		 ,Charge decimal(8,4) NOT NULL 
	   )

--=============== Create Temp DB ==============--

IF OBJECT_ID('tempdb..##TempBellevueLoadCSV') IS NOT NULL
  /*Then it exists*/
  DROP TABLE ##TempBellevueLoadCSV

CREATE TABLE ##TempBellevueLoadCSV
	   (  ID int NOT NULL
	     ,[Date] datetime NULL 
		 ,Clinic int NULL
	     ,Patient int NULL
		 ,Doctor int NULL
		 ,[Procedure] int NULL
		 ,Charge money NULL 
	   )
--============ Insert Patient Data ============--

--[dbo].[##TempBellevueLoadCSV]
--Loads the Patients Visits table.
INSERT INTO tempdb..##TempBellevueLoadCSV
(
ID, [Date], Clinic, Patient, Doctor, [Procedure], Charge
)

SELECT    ID 
	     ,[Date] 
		 ,Clinic
	     ,Patient 
		 ,Doctor 
		 ,[Procedure] 
		 ,Charge 
FROM Patients.dbo.Visits	   

--Checking...
SELECT * FROM ##TempBellevueLoadCSV
--==============================================--


--============== Create Patient Testing DB ===============--
--=================== [PatientsTEST] =====================--
--========================================================--

--=============== Create Patients Visits =================--	  
use master
go
drop database [PatientsTEST]
go
Create database PatientsTEST
go
use PatientsTEST
go
EXEC sp_changedbowner 'sa'
go
CREATE TABLE PatientsTEST.dbo.Visits
	   (  ID int identity (1,1) primary key NOT NULL
	     ,[Date] datetime NULL 
		 ,Clinic int NULL
	     ,Patient int NULL
		 ,Doctor int NULL
		 ,[Procedure] int NULL
		 ,Charge money NULL 
	   )
SELECT * from PatientsTEST.dbo.Visits

truncate table PatientsTEST.dbo.Visits

SELECT * from PatientsTEST.dbo.Visits

--============= Create Patients Patients =================--

DROP TABLE PatientsTEST.dbo.Patients
CREATE TABLE PatientsTEST.dbo.Patients
		( ID int identity (1,1) primary key  NOT NULL --Note: other datatypes Char lengths from flat files, output lengths below this.
		  ,FName varchar(28) NULL --WSTR 50 
		  ,LName varchar(29) NULL --WSTR 50
		  ,Email varchar(100) NULL--WSTR 50
		  ,[Addresss] varchar(97) NULL --WSTR 50
		  ,City varchar(72) NULL --WSTR 50
		  ,[State] varchar(50) NULL --WSTR 50
		  ,ZipCode int NULL --WSTR 50
		)

--Code for derived column (SSIS): (ISNULL(FirstName) ? "" : FirstName) + " " + (ISNULL(LastName) ? "" : LastName)
truncate table PatientsTEST.dbo.Patients

SELECT * from PatientsTEST.dbo.Patients
go

--============== Create Patients Clinics =================--
--Note: Clinics is missing State, ZipCode.
CREATE TABLE PatientsTEST.dbo.Clinics
		( ID int identity (1,1) primary key NOT NULL
		  ,[Name] varchar(50) NULL
		  ,[Address] varchar(100) NULL
		  ,City varchar(50) NULL
		)

select * from Patients.dbo.Clinics
go
--============== Create Patients Doctors =================--

CREATE TABLE PatientsTEST.dbo.Doctors
		( ID int identity (1,1) primary key NOT NULL
		  ,FName varchar(28) NULL
		  ,LName varchar(19) NULL
		)
go
--============== Create Patients Procedures ===============--

CREATE TABLE patientsTEST.dbo.[Procedures]
		( ID int identity primary key NOT NULL
		  ,[Name] varchar(100) NULL
		  ,[Desc] varchar(1000) NULL
		  ,Charge money NULL
		)

SELECT * FROM [DWCorporateReports].dbo.[DimPatient]
TRUNCATE TABLE [DWCorporateReports].dbo.[DimPatient]
--========================================================--

SELECT CAST('0000-00-00 ' AS date) + [Date] AS [Datetime]
      ,Patient
      ,ISNULL(Doctor,-1)
      ,[Procedure]
      ,CAST(Charge AS decimal(8,2)) AS ChargeDecimal 

FROM ##TempBellevueLoadCSV

--DECLARE @Date char(8)
--set @Date='12312009'
--SELECT CONVERT(datetime,RIGHT(@Date,4)+LEFT(@Date,2)+SUBSTRING(@Date,3,2))

--DECLARE @Date varchar(8)
--set @Date='12312050'
--SELECT CONVERT(datetime,RIGHT(@Date,4)+LEFT(@Date,2)+SUBSTRING(@Date,3,2))

--works...
SELECT 
		 --'0000-00-00 '+ SUBSTRING(CAST(t.[Date] AS varchar(8)), 1, 7)+'0.000' AS [Date]
		 CAST('0000-00-00 '+ SUBSTRING(CAST(t.[Date] AS varchar(8)),1, 7)+'0.000' AS varchar) AS [Date]
	     ,Patient 
		 ,Doctor 
		 ,[Procedure] 
		 ,CAST(Charge AS decimal(8,2)) AS Charge 
FROM ##TempBellevueLoadCSV as t
-------------------------
SELECT 
		 --'0000-00-00 '+ SUBSTRING(CAST(t.[Date] AS varchar(8)), 1, 7)+'0.000' AS [Date]
		 CAST(CONVERT(varchar, GETDATE())+' '+[Date] AS varchar(50)) AS [Date]
	     ,Patient 
		 ,Doctor 
		 ,[Procedure] 
		 ,CAST(Charge AS decimal(8,2)) AS Charge 
FROM ##TempBellevueLoadCSV as t

-------------------------
--works...
DECLARE @Date varchar(8)
set @Date= GETDATE()
SELECT CONVERT(datetime,RIGHT(@Date,4)+LEFT(@Date,2)+SUBSTRING(@Date,3,2))
------------------------
DECLARE @Date varchar(8)
SET @Date= GETDATE()

SELECT @Date+SUBSTRING(@Date,4,2)+RIGHT(@Date,2)
--SELECT CONVERT(datetime, '20090101')

------------------------
DECLARE @Date varchar(8)
set @Date= GETDATE()
SELECT 
       
	   --convert(datetime, [Date], 108) -- hh:mm:ss
	   @Date+LEFT([Date],7)+RIGHT([Date],8)
	   [Date]
	  ,Patient
	  ,ISNULL(Doctor,-1) AS Doctor
      ,[Procedure]
      ,CAST(Charge AS decimal(8,2)) AS ChargeDecimal 
FROM ##TempBellevueLoadCSV

-----------------------
SELECT [Date]
	  ,Patient
	  ,ISNULL(Doctor,-1) AS Doctor
      ,[Procedure]
      ,CAST(Charge AS decimal(8,2)) AS ChargeDecimal 
FROM ##TempBellevueLoadCSV


SELECT GETDATE()
Select * from Patients.dbo.Visits


--------------------------------

SELECT CONVERT(DATETIME,[Date],103)[Date]
,Patient
,ISNULL(Doctor,-1) AS Doctor
,[Procedure]
,CAST(Charge AS decimal(8,2)) AS ChargeDecimal 
FROM ##TempBellevueLoadCSV


-------------------------------
SELECT --works..
		 --'0000-00-00 '+ SUBSTRING(CAST(t.[Date] AS varchar(8)), 1, 7)+'0.000' AS [Date]
		 CAST(CONVERT(varchar, GETDATE())+' '+[Date] AS varchar(50)) AS [Date]
	     ,Patient 
		 ,Doctor 
		 ,[Procedure] 
		 ,CAST(Charge AS decimal(8,2)) AS Charge 
FROM ##TempBellevueLoadCSV as t

------------------------------
------------------------------
--Look's exactly like what I need, but won't cast into datetime.
DECLARE @Date3 date
SET @Date3 = CAST(GetDate() AS varchar)


SELECT --works..
		 --'0000-00-00 '+ SUBSTRING(CAST(t.[Date] AS varchar(8)), 1, 7)+'0.000' AS [Date]
		  CONVERT(varchar, @Date3)+[Date]+RIGHT([DATE],3) AS [Date]
		   
		

	     ,Patient 
		 ,Doctor 
		 ,[Procedure] 
		 ,CAST(Charge AS decimal(8,2)) AS Charge 
FROM ##TempBellevueLoadCSV as t

SELECT * FROM Patients.dbo.Visits
--- 09:47:11.895799
-----------------------------------------------
-----------------------------------------------
SELECT CONVERT(TIME,[Date],103) AS [Date]
,Patient
,ISNULL(Doctor,-1) AS Doctor
,[Procedure]
,CAST(Charge AS decimal(8,2)) AS ChargeDecimal 
FROM ##TempBellevueLoadCSV

-----------------------------------------------
Select * 
from Patients.[dbo].[Visits]

