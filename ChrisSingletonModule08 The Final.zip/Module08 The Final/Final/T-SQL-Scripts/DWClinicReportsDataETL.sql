
/*
Created BY: Chris Singleton
BUSIT 210 - Module08 Final
Date: 03/03/2017 

Flush and fill ETL Script for DWClinicReportsData Warehouse. 
*/

--========================= [DWClinicReportData] ============================--
--============== Create The DWClinicReportData Database (OLAP) ==============--
--===========================================================================--

USE [master]
GO
If EXISTS (Select * from Sysdatabases Where Name = 'DWClinicReportData')
	BEGIN 
		ALTER DATABASE [DWClinicReportData] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
		DROP DATABASE [DWClinicReportData]
		PRINT 'DWClinicReportData: Dropped Database Sucessfully.' 
		   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))
	END

GO

CREATE DATABASE [DWClinicReportData] ON PRIMARY
   (NAME = N'DWClinicReportData'
   , FILENAME = N'C:\_BISolutions\Module08\Patients Doctors Clincs DBs\Patients Doctors Clinics DB\DWClinicReportData.mdf' --Store Database Here
   , SIZE = 10MB
   , MAXSIZE = 1GB
   , FILEGROWTH = 10MB)
   LOG ON
   (NAME = N'DWClinicReportData_log' 
   , FILENAME = N'C:\_BISolutions\Module08\Patients Doctors Clincs DBs\Patients Doctors Clinics DB\DWClinicReportData.LDF'--Store Log File Here
   , SIZE = 1MB
   , MAXSIZE = 1GB
   , FILEGROWTH = 10MB)
GO

USE DWClinicReportData;
GO

CREATE TABLE DimDates
(	 DateKey int IDENTITY PRIMARY KEY  
	,FullDate datetime Not Null
	,FullDateName nvarchar (50) Not Null 
	,MonthID int Not Null
	,[MonthName] nvarchar(50) Not Null
	,YearID int Not Null
	,YearName nvarchar(50) Not Null
);
GO

CREATE TABLE DimClinics
(	 ClinicKey int IDENTITY PRIMARY KEY  
	,ClinicID int Not Null
	,ClinicName nvarchar(100) Not Null 
	,ClinicAddress nvarchar(100) Not Null
	,ClinicCity nvarchar(100) Not Null
	,ClinicState nvarchar(100) Not Null 
	,ClinicZip nvarchar(5) Not Null 
);
GO

CREATE TABLE DimDoctors
(	 DoctorKey int IDENTITY PRIMARY KEY  
	,DoctorID int Not Null  
	,DoctorFullName nvarchar(200) Not Null 
	,DoctorEmailAddress nvarchar(100) Not Null  
	,DoctorAddress nvarchar(100) Not Null
	,DoctorCity nvarchar(100) Not Null
	,DoctorState nvarchar(100) Not Null
	,DoctorZip nvarchar(5) Not Null 
);
GO

CREATE TABLE DimShifts 
(	 ShiftKey int IDENTITY PRIMARY KEY  
	,ShiftID int Not Null
	,ShiftStart time(0) Not Null
	,ShiftEnd time(0) Not Null
);
GO

CREATE TABLE FactDoctorShifts
(	 DoctorsShiftID int Not Null
	,ShiftDateKey int References DimDates(DateKey) Not Null
	,ClinicKey int References DimClinics(ClinicKey) Not Null
	,ShiftKey int References DimShifts(ShiftKey) Not Null
	,DoctorKey int References DimDoctors(DoctorKey) Not Null
	,HoursWorked int
	PRIMARY KEY(DoctorsShiftID, ShiftDateKey , ClinicKey, ShiftKey, DoctorKey)
);
go

CREATE TABLE DimProcedures
(	 ProcedureKey int IDENTITY PRIMARY KEY  
	,ProcedureID int Not Null
	,ProcedureName varchar(100) Not Null
	,ProcedureDesc varchar(1000) Not Null
	,ProcedureCharge money Not Null 
);
GO

CREATE TABLE DimPatients
(    PatientKey int IDENTITY PRIMARY KEY  
	,PatientID int Not Null
	,PatientFullName varchar(100) Not Null
	,PatientEmail varchar(100) Not Null
	,PatientAddress varchar(100) Not Null
	,PatientCity varchar(100) Not Null
	,PatientState varchar(100) Not Null
	,PatientZipCode int Not Null
);
GO

CREATE TABLE FactVisits
(	 VisitKey int Not Null
	,DateKey int References DimDates(DateKey) Not Null
	,ClinicKey int References DimClinics(ClinicKey) Not Null
	,PatientKey int References DimPatients(PatientKey) Not Null
	,DoctorKey int References DimDoctors(DoctorKey) Not Null
	,ProcedureKey int References DimProcedures(ProcedureKey) Not Null 
	,Charge money  Not Null
	Primary Key(VisitKey, DateKey, ClinicKey, PatientKey, DoctorKey, ProcedureKey)
);
GO

		--====================================================================--
		--================= Drop Foreign Keys Constaints =====================--
		--====================================================================--

			ALTER TABLE [dbo].[FactSalesOrders] 
					DROP CONSTRAINT FK_OrderDateKey 
			ALTER TABLE [dbo].[FactSalesOrders] 
					DROP CONSTRAINT FK_CustomerKey 
			ALTER TABLE [dbo].[FactSalesOrders] 
					DROP CONSTRAINT FK_ProductKey 

		--====================================================================--
		--====== Clear all tables and reset their Identity Auto Number =======--
		--====================================================================--

			--===========Trancate Table Tables to reset Auto Number===========--

			TRUNCATE TABLE 
				  [DWAdventureWorks_Basics].dbo.DimCustomers
			TRUNCATE TABLE
				  [DWAdventureWorks_Basics].dbo.DimDates
			TRUNCATE TABLE
				  [DWAdventureWorks_Basics].dbo.DimProducts
			TRUNCATE TABLE
				  [DWAdventureWorks_Basics].dbo.FactSalesOrders 

		--====================================================================--
		--==================== Fill DimCustomer Table ========================--
		--====================================================================--




/*
Notes from discussion board: 

You have to write that code. Last time I gave it to you. 
What you are looking at is the SSIS default. 
I already gave you code for validating Emails, but this time the emails are OK,
but the Street addresses are messed up in [Patients].[dbo].[Patients].

1). So look at the data in [Patients].[dbo].[Patients].
Decided what is messed up.

2). Find a regx for street addresses.
Use the regx to validate good from bad addresses. 

3). Keep the good and let's change the bad ones to null (we will pretend that we will get
the correct address from the customer later.) 

4). You will have to do some simple processing for the text files too,
but I see from the next question that I need to fix something in those, before you can continue. 

So, please leave the text files alone for now and get the Databases to DW ETL working.

5). The big issues is that one of the clinics does not include the Clinic ID column,
so you have to use scripting to add it in. You can use SQL and a staging table or
some None SQL code to add in the number. 

--------------------------------------------------
Below regex would match all the lines which has atleast two words where
the first word won't contain any character other than letter or digit. 
And the following one or more words are composed of letters or digits 
or underscore or hyphen or single quotes.

@"^[A-Za-z0-9]+(?:\s[A-Za-z0-9'_-]+)+$"

*/