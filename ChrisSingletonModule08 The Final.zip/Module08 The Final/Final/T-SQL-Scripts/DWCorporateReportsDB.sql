/*
Created BY: Chris Singleton
BUSIT 210 - Module08 Final
Date: 03/20/2017  
*/

--========================= [DWCorporateReports] ============================--
--============== Create The DWCorporateReports Database (OLAP) ==============--
--===========================================================================--


USE [master]
GO
If EXISTS (Select * from Sysdatabases Where Name = 'DWCorporateReports')
	BEGIN 
		ALTER DATABASE [DWCorporateReports] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
		DROP DATABASE [DWCorporateReports]
		PRINT 'DWCorporateReports: Dropped Database Sucessfully.' 
		   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))
	END
GO

CREATE DATABASE [DWCorporateReports] ON PRIMARY
   (NAME = N'DWCorporateReports'
   , FILENAME = N'C:\_BISolutions\Module08 The Final\Final\DWCorporateReports DB\DWCorporateReports.mdf' --Store Database Here
   , SIZE = 10MB
   , MAXSIZE = 1GB
   , FILEGROWTH = 10MB)
   LOG ON
   (NAME = N'DWCorporateReports_log' 
   , FILENAME = N'C:\_BISolutions\Module08 The Final\Final\DWCorporateReports DB\DWCorporateReports.LDF'--Store Log File Here
   , SIZE = 1MB
   , MAXSIZE = 1GB
   , FILEGROWTH = 10MB)
GO

USE DWCorporateReports;
GO

CREATE TABLE DimDate
(	 DateKey int IDENTITY PRIMARY KEY  
	,FullDate datetime Not Null
	,FullDateName nvarchar (50) Not Null 
	,MonthID int Not Null
	,[MonthName] nvarchar(50) Not Null
	,YearID int Not Null
	,YearName nvarchar(50) Not Null
);
GO

CREATE TABLE DimClinic
(	 ClinicKey int IDENTITY PRIMARY KEY  
	,ClinicID int Not Null
	,ClinicName nvarchar(50) Not Null 
	,ClinicAddress nvarchar(50) Not Null
	,ClinicCity nvarchar(50) Not Null
	,ClinicState char(2) Not Null 
	,ClinicZip char(10) Not Null 
);
GO

CREATE TABLE DimDoctor
(	 DoctorKey int IDENTITY PRIMARY KEY  
	,DoctorID int Not Null  
	,DoctorFullName nvarchar(50) Not Null 
	,DoctorEmailAddress nvarchar(50) Not Null  
	,DoctorAddress nvarchar(50) Not Null
	,DoctorCity nvarchar(50) Not Null
	,DoctorState char(2) Not Null
	,DoctorZip char(10) Not Null 
);
GO

CREATE TABLE DimShift 
(	 ShiftKey int IDENTITY PRIMARY KEY  
	,ShiftID int Not Null
	,ShiftStart time(0) Not Null
	,ShiftEnd time(0) Not Null
);
GO

--CREATE TABLE FactDoctorShifts
--(	 DoctorsShiftID int Not Null --Added sorogate key as primary.
--	,ShiftDateKey int References DimDates(DateKey) Not Null
--	,ClinicKey int References DimClinics(ClinicKey) Not Null
--	,ShiftKey int References DimShifts(ShiftKey) Not Null
--	,DoctorKey int References DimDoctors(DoctorKey) Not Null
--	,HoursWorked int
--	PRIMARY KEY(DoctorsShiftID, ShiftDateKey , ClinicKey, ShiftKey, DoctorKey)  --Should be mostly foreign keys.
--);

CREATE TABLE FactDoctorShift
(	 DoctorsShiftKey int IDENTITY PRIMARY KEY 
    ,DoctorsShiftID int Not Null
	,ShiftDateKey int Not Null
	,ClinicKey int Not Null
	,ShiftKey int Not Null
	,DoctorKey int Not Null
	,HoursWorked decimal(3,2)--HoursWorked int --Changed HoursWorked to Decimal datatype.
	--PRIMARY KEY(DoctorsShiftID, ShiftDateKey , ClinicKey, ShiftKey, DoctorKey)
);
GO

CREATE TABLE DimProcedure
(	 ProcedureKey int IDENTITY PRIMARY KEY  
	,ProcedureID int Not Null
	,ProcedureName varchar(100) Not Null
	,ProcedureDesc varchar(1000) Not Null
	,ProcedureCharge decimal(18,2) Not Null --Changed from money to decimal. 
);
GO

CREATE TABLE DimPatient
(    PatientKey int IDENTITY PRIMARY KEY  
	,PatientID int Not Null
	,PatientFullName varchar(50) Not Null
	,PatientEmail varchar(50) Not Null
	,PatientAddress varchar(50) Not Null
	,PatientCity varchar(50) Not Null
	,PatientState char(2) Not Null
	,PatientZipCode char(10) Not Null
);
GO

--CREATE TABLE FactVisits
--(	 VisitKey int Not Null --Should be Primary Key only. 
--	,DateKey int References DimDates(DateKey) Not Null
--	,ClinicKey int References DimClinics(ClinicKey) Not Null
--	,PatientKey int References DimPatients(PatientKey) Not Null
--	,DoctorKey int References DimDoctors(DoctorKey) Not Null
--	,ProcedureKey int References DimProcedures(ProcedureKey) Not Null 
--	,Charge money  Not Null
--	Primary Key(VisitKey, DateKey, ClinicKey, PatientKey, DoctorKey, ProcedureKey) --Should be mostly foreign keys.
--);

CREATE --DROP
     TABLE FactVisit
(	 VisitKey int PRIMARY KEY Not Null
	,DateKey int Not Null
	,ClinicKey int Not Null
	,PatientKey int Not Null
	,DoctorKey int Not Null
	,ProcedureKey int Not Null 
	,Charge decimal(18,2)  Not Null --Changed from Money to decimal.
);
GO

--========================= [DWCorporateReports] ============================--
--===================== Add Foreign Key Constraints =========================--
--===========================================================================--
    --FactDoctorShifts Table
    ALTER TABLE FactDoctorShift 
	ADD CONSTRAINT fk_DimDates_ShiftDateKey_DateKey
	FOREIGN KEY (ShiftDateKey) 
	REFERENCES DimDate (DateKey) --Constraint in the FactDoctorShifts Table.

	ALTER TABLE FactDoctorShift 
	ADD CONSTRAINT fk_DimClinics_ClinicKey 
	FOREIGN KEY (ClinicKey) 
	REFERENCES DimClinic (ClinicKey) --Constraint in the FactDoctorShifts Table.

	ALTER TABLE FactDoctorShift 
	ADD CONSTRAINT fk_DimShifts_ShiftKey
	FOREIGN KEY (ShiftKey) 
	REFERENCES DimShift (ShiftKey) --Constraint in the FactDoctorShifts Table.

	ALTER TABLE FactDoctorShift 
	ADD CONSTRAINT fk_DimDoctors_DoctorKey
	FOREIGN KEY (DoctorKey) 
	REFERENCES DimDoctor (DoctorKey) --Constraint in the FactDoctorShifts Table.

	--FactVisits Table
	ALTER TABLE FactVisit 
	ADD CONSTRAINT fk_DimDates_DateKey 
	FOREIGN KEY (DateKey) 
	REFERENCES DimDate (DateKey) --Constraint in the FactVisits Table.

	ALTER TABLE FactVisit 
	ADD CONSTRAINT fk_DimClinics_ClinicKey_ClinicKey 
	FOREIGN KEY (ClinicKey) 
	REFERENCES DimClinic (ClinicKey) --Constraint in the FactVisits Table.

	ALTER TABLE FactVisit 
	ADD CONSTRAINT fk_DimPatients_PatientKey 
	FOREIGN KEY (PatientKey) 
	REFERENCES DimPatient (PatientKey) --Constraint in the FactVisits Table.

	--Because of NULLS which will be changed to DoctorKey 0.
	--ALTER TABLE FactVisit 
	--ADD CONSTRAINT fk_DimDoctors_DoctorKey_DoctorKey 
	--FOREIGN KEY (DoctorKey) 
	--REFERENCES DimDoctor (DoctorKey) --Constraint in the FactVisits Table.

	ALTER TABLE FactVisit 
	ADD CONSTRAINT fk_DimProcedures_ProcedureKey 
	FOREIGN KEY (ProcedureKey) 
	REFERENCES DimProcedure (ProcedureKey) --Constraint in the FactVisits Table.
GO
	PRINT 'DWCorporateReports: Created Database with Constraints Sucessfully.' 
		   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))

GO