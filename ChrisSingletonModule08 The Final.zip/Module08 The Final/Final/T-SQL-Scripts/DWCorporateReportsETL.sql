/*
Created BY: Chris Singleton
BUSIT 210 - Module08 Final
Date: 03/20/2017  
*/
/*
    ***Please install this database.

Observations/Changes: Data warehouse table names are most commonly singular, not plural.
                      Data types needed to be changed (money to decimal, state char 2
					  ZipCodes char 10 and such. Excessive large character settings).
					  OLTP Patients has two null doctor keys, changed to -1 and Clinic
					  key nulls to 0 in order to reduce confusion. 
*/

--========================= [DWCorporateReports] ============================--
--================ Create The DWCorporateReports ETL (OLAP) =================--
--===========================================================================--

USE [master]
GO
If EXISTS (Select * from Sysdatabases Where Name = 'DWCorporateReports')
	BEGIN 
		ALTER DATABASE [DWCorporateReports] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
		DROP DATABASE [DWCorporateReports]
		PRINT 'DWCorporateReports: Dropped Database Sucessfully.' 
		   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))
	END
GO

CREATE DATABASE [DWCorporateReports] ON PRIMARY
   (NAME = N'DWCorporateReports'
   , FILENAME = N'C:\_BISolutions\Module08 The Final\Final\DWCorporateReports DB\DWCorporateReports.mdf' --Store Database Here
   , SIZE = 10MB
   , MAXSIZE = 1GB
   , FILEGROWTH = 10MB)
   LOG ON
   (NAME = N'DWCorporateReports_log' 
   , FILENAME = N'C:\_BISolutions\Module08 The Final\Final\DWCorporateReports DB\DWCorporateReports DB.LDF'--Store Log File Here
   , SIZE = 1MB
   , MAXSIZE = 1GB
   , FILEGROWTH = 10MB)
GO

USE DWCorporateReports;
GO
IF (OBJECT_ID('spCreateTablesDWCorporateReports')IS NOT NULL) 
DROP PROCEDURE spCreateTablesDWCorporateReports;

GO
CREATE PROCEDURE spCreateTablesDWCorporateReports

AS
/*
Create By: Chris Singleton
Date: 03/05/2017
Purpose: Create DWCorporateReports database Tables.
*/
BEGIN TRY --Begin with a try statement (Error Handling).
	CREATE --DROP
		 TABLE DimDates
	(	 DateKey int IDENTITY (1,1) PRIMARY KEY  
		,FullDate datetime Not Null
		,FullDateName nvarchar (50) Not Null 
		,MonthID int Not Null
		,[MonthName] nvarchar(50) Not Null
		,YearID int Not Null
		,YearName nvarchar(50) Not Null
	)


	CREATE --DROP
		 TABLE DimClinics
	(	 ClinicKey int IDENTITY (1,1) PRIMARY KEY  
		,ClinicID int Not Null
		,ClinicName nvarchar(50) Not Null --size changed.
		,ClinicAddress nvarchar(50) Not Null --size changed.
		,ClinicCity nvarchar(50) Not Null --size changed.
		,ClinicState char(2) DEFAULT 'WA' Not Null --changed datatype.
		,ClinicZip char(10) DEFAULT 'UNKNOWN' Not Null --Changed datatype.
	)


	CREATE --DROP
		 TABLE DimDoctors
	(	 DoctorKey int IDENTITY (1,1) PRIMARY KEY  
		,DoctorID int Not Null  
		,DoctorFullName nvarchar(100) Not Null 
		,DoctorEmailAddress nvarchar(50) Not Null --Changed size. 
		,DoctorAddress nvarchar(50) Not Null --Changed size.
		,DoctorCity nvarchar(50) Not Null --Changed size.
		,DoctorState char(2) Not Null --Changed datatype.
		,DoctorZip char(10) Not Null --Changed datatype.
	)


	CREATE --DROP
		 TABLE DimShifts 
	(	 ShiftKey int IDENTITY (1,1) PRIMARY KEY  
		,ShiftID int Not Null
		,ShiftStart time(0) Not Null
		,ShiftEnd time(0) Not Null
	)

	CREATE --DROP
		 TABLE FactDoctorsShifts
	(	 DoctorShiftKey int IDENTITY (1,1) PRIMARY KEY 
		,DoctorShiftID int Not Null
		,ShiftDateKey int Not Null
		,ClinicKey int Not Null
		,ShiftKey int Not Null
		,DoctorKey int Not Null
		,HoursWorked decimal(18,4)--HoursWorked int --Changed HoursWorked to Decimal datatype(fractions).
		--PRIMARY KEY(DoctorsShiftID, ShiftDateKey , ClinicKey, ShiftKey, DoctorKey) --Should be mostly foreign keys.
	)

	CREATE --DROP
		 TABLE DimProcedures
	(	 ProcedureKey int IDENTITY (1,1) PRIMARY KEY  
		,ProcedureID int Not Null
		,ProcedureName varchar(100) Not Null
		,ProcedureDesc varchar(1000) Not Null
		,ProcedureCharge decimal(18,4) Not Null --Changed from money to decimal.
	)


	CREATE --DROP
		 TABLE DimPatients
	(    PatientKey int IDENTITY (1,1) PRIMARY KEY  
		,PatientID int Not Null
		,PatientFullName varchar(100) Not Null
		,PatientEmail varchar(50) Not Null --Size changed.
		,PatientAddress varchar(50) DEFAULT 'None Found' Not Null --Size changed.
		,PatientCity varchar(50) DEFAULT 'None Found' Not Null --Size changed.
		,PatientState char(2) DEFAULT '-1' Not Null --Changed datatype.
		,PatientZipCode char(10) DEFAULT 'None Found' Not Null --Changed datatype.
	)


	CREATE --DROP
		 TABLE FactVisits
	(	 VisitKey int identity (1,1) PRIMARY KEY Not Null  
		,DateKey int Not Null
		,ClinicKey int DEFAULT -2 Not Null
		,PatientKey int Not Null
		,DoctorKey int Not Null
		,ProcedureKey int Not Null 
		,Charge decimal(18,4)  Not Null --Changed from Money to decimal.
	)
	
END TRY 
BEGIN CATCH
	PRINT 'Problem found with Creating Database: spCreateTablesDWCorporateReports!!! ' 
	-- Whoops, there was an error
	-- Raise an error with the details of the exception
	DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int, @ErrLineNum int
	SELECT @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY(), @ErrLineNum = ERROR_LINE()
  
	RAISERROR(@ErrMsg, @ErrSeverity, 1, @ErrLineNum)
END CATCH --End Catch.
GO
--Call the Stored Procedure.
EXECUTE spCreateTablesDWCorporateReports
GO
USE DWCorporateReports
GO
--NOTE: Installing foreign keys at the end, so no need to drop constraints (starting from scratch).
--Kept for referencing and if needed to use. 
--========================= [DWCorporateReports] ============================--
--================== Drop the Foreign Key Constraints =======================--
--===========================================================================--
--FactDoctorShift
/*

ALTER TABLE [dbo].[FactDoctorsShifts] 
        DROP CONSTRAINT fk_DimDates_ShiftDateKey_DateKey 

ALTER TABLE [dbo].[FactDoctorsShifts] 
        DROP CONSTRAINT fk_DimClinics_ClinicKey 

ALTER TABLE [dbo].[FactDoctorsShifts] 
        DROP CONSTRAINT fk_DimShifts_ShiftKey

ALTER TABLE [dbo].[FactDoctorsShifts] 
        DROP CONSTRAINT fk_DimDoctors_DoctorKey

--FactVisit
ALTER TABLE [dbo].[FactVisits] 
        DROP CONSTRAINT fk_DimDates_DateKey

ALTER TABLE [dbo].[FactVisits] 
        DROP CONSTRAINT fk_DimClinics_ClinicKey_ClinicKey

ALTER TABLE [dbo].[FactVisits] 
        DROP CONSTRAINT fk_DimPatients_PatientKey	
		
ALTER TABLE [dbo].[FactVisits] 
        DROP CONSTRAINT fk_DimProcedures_ProcedureKey			 
GO

*/
--========================= [DWCorporateReports] ============================--
--=========================== Truncate Tables ===============================--
--===========================================================================--
/*

TRUNCATE TABLE DWCorporateReports.dbo.DimDates

TRUNCATE TABLE DWCorporateReports.dbo.DimClinics

TRUNCATE TABLE DWCorporateReports.dbo.DimDoctors

TRUNCATE TABLE DWCorporateReports.dbo.DimShifts

TRUNCATE TABLE DWCorporateReports.dbo.FactDoctorsShifts

TRUNCATE TABLE DWCorporateReports.dbo.DimProcedures

TRUNCATE TABLE DWCorporateReports.dbo.DimPatients

TRUNCATE TABLE DWCorporateReports.dbo.FactVisits

GO

*/
--========================= [DWCorporateReports] ============================--
--======================== Fill Data into OLAP DB ===========================--
--===========================================================================--
IF (OBJECT_ID('spFillDWCorporateReports')IS NOT NULL) 
DROP PROCEDURE spFillDWCorporateReports;
GO
CREATE PROCEDURE spFillDWCorporateReports

AS
/*
Created By: Chris Singleton
Date: 03/05/2017
This stored procedure fills the data DWCorporate data warehouse.
*/
BEGIN TRY --Begin with a try statement (Error Handling).
	SET IDENTITY_INSERT DimDates ON 
	INSERT INTO [DimDates] 
				( [DateKey], [FullDate], [FullDateName], [MonthID], [MonthName], [YearID], [YearName] )
				Values
				  ( -1, Cast('01/01/1900' as datetime), 'Unknown Day', -1, 'Unknown Month', -1 , 'Unknown Year' )
				, ( -2, Cast('01/01/1900' as datetime), 'Corrupt Day', -2, 'Corrupt Month', -2, 'Corrupt Year' )
				--Go
				-- Create variables to hold the start and end date
				DECLARE @StartDate datetime = '01/01/2005'
				DECLARE @EndDate datetime = '01/01/2010' 

				-- Use a while loop to add dates to the table
				DECLARE @DateInProcess datetime
				SET @DateInProcess = @StartDate

				WHILE @DateInProcess <= @EndDate
				 BEGIN

				 -- Add a row into the date dimension table for this date
				 INSERT INTO DimDates 
				 ( [DateKey], [FullDate], [FullDateName], [MonthID], [MonthName], [YearID], [YearName] )
				 VALUES (
					Cast(Convert(nVarchar(50), @DateInProcess, 112) as int) -- [DateKey] = 20050101 to 20101231
				  , @DateInProcess -- [FullDate] = '2005-01-01 00:00:00.000'
				  , DateName(weekday, @DateInProcess ) + ', ' + DateName(mm, @DateInProcess ) + ' ' +  Convert(nVarchar(50), @DateInProcess, 110) -- [DateKey] = 20050101 to 20101231
				  , Month( @DateInProcess ) -- [MonthID]   
				  , DateName( month, @DateInProcess ) -- [MonthName]
				  , Year( @DateInProcess ) -- [YearID] 
				  , Cast( Year(@DateInProcess ) as nVarchar(50) ) -- [YearName] 
				  )  
				 -- Add a day and loop again
				 SET @DateInProcess = DateAdd(d, 1, @DateInProcess)
				 END;

	SET IDENTITY_INSERT DimDates OFF

	PRINT 'DWCorporateReports: DimDates Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))
	--Checking...
	--SELECT * from Dimdates

	--=============== Populate DimClinics =============--

	INSERT INTO DWCorporateReports.dbo.DimClinics 
	(	 --ClinicKey int IDENTITY (1,1) PRIMARY KEY  
		 ClinicID 
		,ClinicName 
		,ClinicAddress
		,ClinicCity
		,ClinicState
		,ClinicZip
	)

	SELECT ClinicID = ISNULL(ClinicID, 0) --Make NULL's to 0.
		  ,ClinicName = CAST(ClinicName AS varchar(50)) 
		  ,ClinicAddress = CAST([Address] AS varchar(50))
		  ,ClinicCity = CAST(City AS varchar(50))
		  ,ClinicState = CAST([State] AS char(2))
		  ,ClinicZip = CAST(Zip AS char(10))
	FROM [DoctorsSchedules].[dbo].[Clinics] 


	PRINT 'DWCorporateReports: DimClinics Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))	

	-- SELECT * FROM DimClinics
	-- SELECT * FROM [DoctorsSchedules].[dbo].[Clinics]

	--=============== Populate DimDoctors =============--

	INSERT INTO DimDoctors
	(	 --DoctorKey int IDENTITY (1,1) PRIMARY KEY  
		 DoctorID   
		,DoctorFullName 
		,DoctorEmailAddress 
		,DoctorAddress 
		,DoctorCity 
		,DoctorState 
		,DoctorZip 
	)

	SELECT DoctorID
		  ,DoctorFullName = Cast(([FirstName] + ' ' + [LastName]) as nVarchar(100))
		  ,DoctorEmailAddress = CAST(EmailAddress AS varchar(50))
		  ,DoctorAddress = CAST([Address] AS varchar(50))
		  ,DoctorCity = CAST(City AS varchar(50))
		  ,DoctorState = CAST([State] AS char(2))
		  ,DoctorZip = CAST(Zip AS char(10))
	FROM [DoctorsSchedules].[dbo].[Doctors]


	PRINT 'DWCorporateReports: DimDoctors Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))

	--=============== Populate DimShifts =============--

	INSERT INTO DimShifts
	(	 --ShiftKey int IDENTITY (1,1) PRIMARY KEY  
		 ShiftID 
		,ShiftStart
		,ShiftEnd 
	)

	SELECT ShiftID = ShiftID
		  ,ShiftStart = ShiftStart
		  ,ShiftEnd = ShiftEnd
	FROM [DoctorsSchedules].[dbo].[Shifts]

	PRINT 'DWCorporateReports: DimShifts Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))

	--============ Populate DimProcedures ============--

	INSERT INTO DimProcedures
	(	 --ProcedureKey int IDENTITY (1,1) PRIMARY KEY  
		 ProcedureID 
		,ProcedureName 
		,ProcedureDesc 
		,ProcedureCharge --money Not Null --Convert to decimal
	)
	SELECT 	 ProcedureID = ID
		,ProcedureName = [Name] --AS ProcedureName
		,ProcedureDesc = [Desc]
		,ProcedureCharge = CAST(Charge AS decimal(8,2))  --money Not Null, Convert to decimal
	FROM [Patients].[dbo].[Procedures]

	PRINT 'DWCorporateReports: DimProcedure Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))

	--============== Populate DimPatients =============--

	INSERT INTO DimPatients
	(    --PatientKey int IDENTITY PRIMARY KEY  
		 PatientID 
		,PatientFullName 
		,PatientEmail 
		,PatientAddress 
		,PatientCity 
		,PatientState 
		,PatientZipCode 
	)
	SELECT PatientID = ID
		  ,PatientFullName = Cast(([FName] + ' ' + [LName]) as nVarchar(100))
		  ,PatientEmail = CAST(Email AS varchar(50))
		  ,PatientAddress = ISNULL(CAST([Address] AS varchar(50)),'None Found')
		  ,PatientCity = CAST(City AS varchar(50))
		  ,PatientState = CAST([State] AS char(2))
		  ,PatientZipCode = CAST(ZipCode AS char(10))
	FROM  [Patients].[dbo].[Patients]

	PRINT 'DWCorporateReports: DimPatients Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))

	--========== Populate FactDoctorsShifts ===========--
	/*
	Problem: 
	Calculated the difference in start and end time values for HoursWorked.
	*/
	--Hour calculation: for time difference.
	
	SELECT 
		ShiftID,
		ShiftStart, 
		ShiftEnd, 
	   (datepart(hh,[ShiftStart]) + datepart(mi,[ShiftStart])/60.0) as StartHour,
	   (datepart(hh,[ShiftEnd]) + datepart(mi,[ShiftEnd])/60.0) as EndHour	
	FROM [DoctorsSchedules].[dbo].[Shifts]

	INSERT INTO DWCorporateReports.dbo.FactDoctorsShifts
	(	 --DoctorsShiftKey int IDENTITY PRIMARY KEY 
		 DoctorShiftID
		,ShiftDateKey 
		,ClinicKey 
		,ShiftKey 
		,DoctorKey 
		,HoursWorked
	)	

   SELECT ds.[DoctorsShiftID]
		  ,da.[DateKey] 
		  ,c.ClinicKey 
		  ,s.ShiftKey 
		  ,d.DoctorKey  
		  ,CASE
	   WHEN(datepart(hh,t.[ShiftStart]) + datepart(mi,t.[ShiftStart])/60.0)  
	   >  (datepart(hh,t.[ShiftEnd]) + datepart(mi,t.[ShiftEnd])/60.0)
	   THEN  (datepart(hh,t.[ShiftEnd]) + datepart(mi,t.[ShiftEnd])/60.0) -(datepart(hh,t.[ShiftStart]) + datepart(mi,t.[ShiftStart])/60.0) + 24
	   ELSE  (datepart(hh,t.[ShiftEnd]) + datepart(mi,t.[ShiftEnd])/60.0) - (datepart(hh,t.[ShiftStart]) + datepart(mi,t.[ShiftStart])/60.0)
	   END AS HoursWorked	  
		  
	FROM [DoctorsSchedules].[dbo].[DoctorShifts] as ds
		 INNER JOIN DWCorporateReports.dbo.[DimDates] as da
				ON ds.ShiftDate = da.FullDate
		 INNER JOIN DWCorporateReports.dbo.[DimClinics] as c
				ON ds.ClinicID = c.ClinicID
		 INNER JOIN DWCorporateReports.dbo.[DimShifts] as s
				ON ds.ShiftID = s.ShiftID
		 INNER JOIN DWCorporateReports.dbo.[DimDoctors] as d
				ON ds.DoctorID = d.DoctorID
		 INNER JOIN [DoctorsSchedules].[dbo].[Shifts] AS t 
		        ON ds.ShiftID = t.ShiftID

	PRINT 'DWCorporateReports: FactDoctorsShifts Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))

	--Checking...
	--SELECT * FROM DWCorporateReports.dbo.FactDoctorsShifts

	--============= Populate FactVisits =============--

	INSERT INTO FactVisits
	(	 --VisitKey int PRIMARY KEY Not Null
     
		 [DateKey] 
		,[ClinicKey] 
		,[PatientKey] 
		,[DoctorKey] 
		,[ProcedureKey] 
		,[Charge]
		
	)

	SELECT dd.DateKey 
		  ,dc.ClinicKey --[DWCorporateReports].[dbo].[DimClinics].[ClinicKey]
		  ,dp.PatientKey  --[DWCorporateReports].[dbo].[DimPatients].[PatientKey]
		  ,doc.DoctorKey--[DWCorporateReports].[dbo].[DimDoctors].[DoctorKey]
		  ,dpro.ProcedureKey --[DWCorporateReports].[dbo].[DimProcedure].[ProcedureKey]
		  ,CAST(v.Charge AS decimal (18,2))   --[Patients].[dbo].[Visits]
	FROM [Patients].[dbo].[Visits] 	AS v
			INNER JOIN [DWCorporateReports].[dbo].[DimDates] AS dd  
				ON CAST(v.[Date] AS date) = CAST(dd.FullDate AS date)

			INNER JOIN [DWCorporateReports].[dbo].[DimClinics] AS dc  
				ON SUBSTRING(CAST(v.Clinic AS VARCHAR(3)), 1, 1)= dc.ClinicID

			INNER JOIN [DWCorporateReports].[dbo].[DimPatients] AS dp  
				ON v.Patient = dp.PatientID

			INNER JOIN [DWCorporateReports].[dbo].[DimDoctors] AS doc  
				ON ISNULL(v.Doctor,-1) = doc.DoctorID

			INNER JOIN [DWCorporateReports].[dbo].[DimProcedures] AS dPro  
				ON v.[Procedure] = dpro.ProcedureID
	WHERE Doctor IS NOT NULL

	UNION ALL
	--Import the null data using union all. 
	SELECT dd.DateKey 
		  ,dc.ClinicKey      
		  ,dp.PatientKey     
		  ,-1 AS DoctorKey   --Set NULLs to -1
		  ,dpro.ProcedureKey 
		  ,v.Charge   --[Patients].[dbo].[Visits]
	FROM [Patients].[dbo].[Visits] 	AS v
			INNER JOIN [DWCorporateReports].[dbo].[DimDates] AS dd  
				ON CAST(v.[Date] AS date) = CAST(dd.FullDate AS date)

			INNER JOIN [DWCorporateReports].[dbo].[DimClinics] AS dc  
				ON SUBSTRING(CAST(v.Clinic AS VARCHAR(3)), 1, 1)= dc.ClinicID

			INNER JOIN [DWCorporateReports].[dbo].[DimPatients] AS dp  
				ON v.Patient = dp.PatientID		

			INNER JOIN [DWCorporateReports].[dbo].[DimProcedures] AS dPro  
				ON v.[Procedure] = dpro.ProcedureID
	WHERE v.Doctor IS NULL --Filter to only nulls.

	PRINT 'DWCorporateReports: FactVisits Populated Sucessfully.' 
			   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))		
	--Checking...
	--select * from [Patients].[dbo].[Visits] where doctor IS NULL
	--select * from [DWCorporateReports].[dbo].[FactVisits]

--========================= [DWCorporateReports] ============================--
--===================== Add Foreign Key Constraints =========================--
--===========================================================================--

    --FactDoctorShifts Table
    ALTER TABLE FactDoctorsShifts 
	ADD CONSTRAINT fk_DimDates_ShiftDateKey_DateKey
	FOREIGN KEY (ShiftDateKey) 
	REFERENCES DimDates (DateKey) --C[dbo].[Patients]onstraint in the FactDoctorShifts Table.

	ALTER TABLE FactDoctorsShifts 
	ADD CONSTRAINT fk_DimClinics_ClinicKey 
	FOREIGN KEY (ClinicKey) 
	REFERENCES DimClinics (ClinicKey) --Constraint in the FactDoctorShifts Table.

	ALTER TABLE FactDoctorsShifts 
	ADD CONSTRAINT fk_DimShifts_ShiftKey
	FOREIGN KEY (ShiftKey) 
	REFERENCES DimShifts (ShiftKey) --Constraint in the FactDoctorShifts Table.

	ALTER TABLE FactDoctorsShifts 
	ADD CONSTRAINT fk_DimDoctors_DoctorKey
	FOREIGN KEY (DoctorKey) 
	REFERENCES DimDoctors (DoctorKey) --Constraint in the FactDoctorShifts Table.

	--FactVisits Table
	ALTER TABLE FactVisits 
	ADD CONSTRAINT fk_DimDates_DateKey 
	FOREIGN KEY (DateKey) 
	REFERENCES DimDates (DateKey) --Constraint in the FactVisits Table.

	ALTER TABLE FactVisits 
	ADD CONSTRAINT fk_DimClinics_ClinicKey_ClinicKey 
	FOREIGN KEY (ClinicKey) 
	REFERENCES DimClinics (ClinicKey) --Constraint in the FactVisits Table.

	ALTER TABLE FactVisits 
	ADD CONSTRAINT fk_DimPatients_PatientKey 
	FOREIGN KEY (PatientKey) 
	REFERENCES DimPatients (PatientKey) --Constraint in the FactVisits Table.

	ALTER TABLE FactVisits 
	ADD CONSTRAINT fk_DimProcedures_ProcedureKey 
	FOREIGN KEY (ProcedureKey) 
	REFERENCES DimProcedures (ProcedureKey) --Constraint in the FactVisits Table.

	PRINT 'DWCorporateReports: Filled Database with Constraints Sucessfully.' 
		   + CAST(CONVERT(varchar, SYSDATETIME(), 121) AS varchar (20))
END TRY 
BEGIN CATCH
	PRINT 'Problem found with Creating Database: spFillDWCorporateReports!!! ' 
	-- Whoops, there was an error
	-- Raise an error with the details of the exception
	DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int, @ErrLineNum int
	SELECT @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY(), @ErrLineNum = ERROR_LINE()
  
	RAISERROR(@ErrMsg, @ErrSeverity, 1, @ErrLineNum)
END CATCH --End Catch.
GO --End of Stored Procedure.
--Call the Procedure.
EXEC spFillDWCorporateReports
GO

--================== [Create Views] ==================--
--================ [Views Used Often] ================--
--====================================================--

--============= Track Doctor Shift Hours =============--
--Checking...
--SELECT * FROM [DWCorporateReports].[dbo].[FactDoctorShifts]
IF OBJECT_ID('vFactDocShiftHoursWorked', 'V') IS NOT NULL
    DROP VIEW vFactDocShiftHoursWorked;
GO
CREATE VIEW vFactDocShiftHoursWorked

AS 
/*
Created By: Chris Singleton
Date: 03/06/2017
Keep Track of the hours worked on shifts. 
*/
SELECT dss.ShiftID
      ,dsf.ShiftDate
	  ,dss.ShiftStart
	  ,dss.ShiftEnd
	  ,fds.HoursWorked
FROM DoctorsSchedules.dbo.Shifts AS dss
	INNER JOIN DWCorporateReports.dbo.FactDoctorsShifts fds
		ON fds.DoctorShiftKey = dss.ShiftID
	INNER JOIN DoctorsSchedules.dbo.DoctorShifts AS dsf
		ON dsf.DoctorsShiftID = dss.ShiftID
GO

--======== Track Doctor Not Inovlved Charges =========--

IF OBJECT_ID('vPatientDocNullCharges', 'V') IS NOT NULL
    DROP VIEW vPatientDocNullCharges;
GO
CREATE VIEW vPatientDocNullCharges

AS
/*
Created By: Chris Singleton
Date: 03/06/2017
Keep Track of Charges for patients where there are no Doctors involved.
Note: Doctor's nulls have been changed to 0 (None).
*/
SELECT pv.ID
      ,CONVERT(varchar, pv.[Date],100) AS [Date Occured] --Easy Read Format.
	  ,CONVERT(varchar,GETDATE(),100) AS [Todays Date]
      ,pv.Clinic
	  ,pv.Patient AS [Patient No.]
	  ,CAST(pp.Fname +' '+ pp.LName AS varchar(100))AS FullName
	  ,pp.Email
	  ,pp.[Address]
	  ,pp.City
	  ,pp.[State]
	  ,pp.ZipCode
	  ,ISNULL(pv.Doctor, 0) AS Doctor
	  ,pv.[Procedure]
	  ,pro.[Name]
	  ,Pro.[Desc]
	  ,pv.Charge  
FROM Patients.dbo.Visits AS pv
	INNER JOIN Patients.dbo.Patients AS pp
		ON pp.ID = pv.ID
	INNER JOIN Patients.dbo.[Procedures] AS pro
		ON pro.ID = pv.ID
WHERE Doctor IS NULL

 
