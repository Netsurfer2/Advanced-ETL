

/*
Chris Singleton
Final - Creates a Testing [Patients] Database For Testing purposes.
*/

--============== Create Patient Testing DB ===============--
--=================== [PatientsTEST] =====================--
--========================================================--

--=============== Create Patients Visits =================--	  
USE MASTER
GO
--DROP DATABASE [PatientsTEST]
--go
CREATE DATABASE PatientsTEST
GO
use PatientsTEST
GO
EXEC sp_changedbowner 'sa'
GO
CREATE TABLE PatientsTEST.dbo.Visits
	   (  ID int identity (1,1) primary key NOT NULL
	     ,[Date] datetime NULL 
		 ,Clinic int NULL
	     ,Patient int NULL
		 ,Doctor int NULL
		 ,[Procedure] int NULL
		 ,Charge money NULL 
	   )

--SELECT * FROM PatientsTEST.dbo.Visits

--TRUNCATE TABLE PatientsTEST.dbo.Visits

--SELECT * FROM PatientsTEST.dbo.Visits

--============= Create Patients Patients =================--
GO
--DROP TABLE PatientsTEST.dbo.Patients
CREATE TABLE PatientsTEST.dbo.Patients
		( ID int identity (1,1) primary key  NOT NULL --Note: other datatypes Char lengths from flat files, output lengths below this.
		  ,FName varchar(28) NULL --WSTR 50 
		  ,LName varchar(29) NULL --WSTR 50
		  ,Email varchar(100) NULL--WSTR 50
		  ,[Addresss] varchar(97) NULL --WSTR 50
		  ,City varchar(72) NULL --WSTR 50
		  ,[State] varchar(50) NULL --WSTR 50
		  ,ZipCode int NULL --WSTR 50
		)

--Code for derived column (SSIS): (ISNULL(FirstName) ? "" : FirstName) + " " + (ISNULL(LastName) ? "" : LastName)
--TRUNCATE TABLE PatientsTEST.dbo.Patients

--SELECT * FROM PatientsTEST.dbo.Patients
GO

--============== Create Patients Clinics =================--
--Note: Clinics is missing State, ZipCode.
CREATE TABLE PatientsTEST.dbo.Clinics
		( ID int identity (1,1) primary key NOT NULL
		  ,[Name] varchar(50) NULL
		  ,[Address] varchar(100) NULL
		  ,City varchar(50) NULL
		)

--SELECT * FROM Patients.dbo.Clinics
GO

--============== Create Patients Doctors =================--

CREATE TABLE PatientsTEST.dbo.Doctors
		( ID int identity (1,1) primary key NOT NULL
		  ,FName varchar(28) NULL
		  ,LName varchar(19) NULL
		)
GO
--============== Create Patients Procedures ===============--

CREATE TABLE patientsTEST.dbo.[Procedures]
		( ID int identity primary key NOT NULL
		  ,[Name] varchar(100) NULL
		  ,[Desc] varchar(1000) NULL
		  ,Charge money NULL
		)
GO
--SELECT * FROM [DWCorporateReports].dbo.[DimPatient]
--TRUNCATE TABLE [DWCorporateReports].dbo.[DimPatient]

--========================================================--

